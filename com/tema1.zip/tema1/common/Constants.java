package com.tema1.helpers;

public final class Constants {
    // add/delete any constants you think you may use
}
